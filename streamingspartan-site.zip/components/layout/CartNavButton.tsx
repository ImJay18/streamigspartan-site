'use client'

import { useCart } from '@/lib/cartContext'

export default function CartNavButton() {
  const { items, openCart } = useCart()
  const total = items.reduce((acc, i) => acc + i.screens, 0)

  return (
    <button
      onClick={openCart}
      style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 8, padding: '8px 16px', fontSize: 14, color: '#fff', background: 'transparent', border: '1px solid #1A1A2E', borderRadius: 8, cursor: 'pointer', transition: 'border-color 0.2s' }}
      onMouseEnter={e => (e.currentTarget.style.borderColor = 'rgba(139,92,246,0.5)')}
      onMouseLeave={e => (e.currentTarget.style.borderColor = '#1A1A2E')}>
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
        <path d="M2 2h2l1.5 7M6 11h7l1.5-5H4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
        <circle cx="7" cy="13.5" r="1" fill="currentColor"/>
        <circle cx="12" cy="13.5" r="1" fill="currentColor"/>
      </svg>
      Mi pedido
      {total > 0 && (
        <div style={{ position: 'absolute', top: -6, right: -6, width: 18, height: 18, borderRadius: '50%', background: 'linear-gradient(135deg,#8B5CF6,#D946EF)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700, color: '#fff' }}>
          {total}
        </div>
      )}
    </button>
  )
}
