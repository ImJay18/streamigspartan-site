'use client'

import { useState, useEffect } from 'react'
import { NAV_LINKS, WHATSAPP_NUMBER } from '@/lib/constants'
import CartNavButton from './CartNavButton'
import { getWhatsAppLink } from '@/lib/utils'

export default function Navbar() {
  const [scrolled, setScrolled]   = useState(false)
  const [menuOpen, setMenuOpen]   = useState(false)

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', fn)
    return () => window.removeEventListener('scroll', fn)
  }, [])

  const navStyle: React.CSSProperties = {
    position:       'fixed',
    top:            0, left: 0, right: 0,
    zIndex:         50,
    transition:     'background 0.3s, border-color 0.3s',
    background:     scrolled ? 'rgba(5,5,5,0.95)' : 'transparent',
    backdropFilter: scrolled ? 'blur(12px)' : 'none',
    borderBottom:   scrolled ? '1px solid #1A1A2E' : '1px solid transparent',
  }

  const grad = 'linear-gradient(135deg, #8B5CF6 0%, #D946EF 100%)'

  return (
    <header style={navStyle}>
      <nav style={{ maxWidth: 1280, margin: '0 auto', padding: '0 24px', height: 64, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>

        {/* Logo */}
        <a href="/" style={{ display: 'flex', alignItems: 'center', textDecoration: 'none', flexShrink: 0 }}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/logo.png" alt="Streaming Spartan" style={{ height: 44, width: 'auto', objectFit: 'contain' }}/>
        </a>

        {/* Desktop links */}
        <ul style={{ display: 'flex', alignItems: 'center', gap: 4, listStyle: 'none', margin: 0, padding: 0 }} className="hidden-mobile">
          {NAV_LINKS.map(l => (
            <li key={l.href}>
              <a href={l.href} style={{ padding: '8px 14px', fontSize: 14, color: '#A1A1AA', textDecoration: 'none', borderRadius: 8, transition: 'color 0.2s' }}
                onMouseEnter={e => (e.currentTarget.style.color = '#fff')}
                onMouseLeave={e => (e.currentTarget.style.color = '#A1A1AA')}>
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        {/* Desktop CTAs */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }} className="hidden-mobile">
          <CartNavButton />
          <a href={getWhatsAppLink(WHATSAPP_NUMBER, '¡Hola! Me interesa conocer más sobre los planes de Streaming Spartan.')}
            target="_blank" rel="noopener noreferrer"
            style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 16px', fontSize: 14, fontWeight: 600, color: '#fff', background: grad, borderRadius: 8, textDecoration: 'none', transition: 'opacity 0.2s' }}
            onMouseEnter={e => (e.currentTarget.style.opacity = '0.9')}
            onMouseLeave={e => (e.currentTarget.style.opacity = '1')}>
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M13.6 2.4A7.8 7.8 0 002.1 12.5L1 15l2.6-1.1A7.8 7.8 0 0013.6 2.4z" stroke="white" strokeWidth="1.5" strokeLinejoin="round"/>
            </svg>
            WhatsApp
          </a>
        </div>

        {/* Mobile burger */}
        <button onClick={() => setMenuOpen(!menuOpen)} style={{ display: 'none', padding: 8, background: 'none', border: 'none', cursor: 'pointer', color: '#A1A1AA' }} className="show-mobile" aria-label="Menú">
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            {menuOpen
              ? <path d="M5 5l12 12M17 5L5 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
              : <path d="M3 7h16M3 11h16M3 15h16" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>}
          </svg>
        </button>
      </nav>

      {/* Mobile menu */}
      {menuOpen && (
        <div style={{ background: 'rgba(5,5,5,0.98)', borderBottom: '1px solid #1A1A2E', padding: '8px 24px 16px' }}>
          {NAV_LINKS.map(l => (
            <a key={l.href} href={l.href} onClick={() => setMenuOpen(false)}
              style={{ display: 'block', padding: '10px 12px', fontSize: 14, color: '#A1A1AA', textDecoration: 'none', borderRadius: 8 }}>
              {l.label}
            </a>
          ))}
          <a href={getWhatsAppLink(WHATSAPP_NUMBER)} target="_blank" rel="noopener noreferrer"
            style={{ display: 'block', marginTop: 8, padding: '10px 12px', fontSize: 14, fontWeight: 600, color: '#fff', background: grad, borderRadius: 8, textDecoration: 'none', textAlign: 'center' }}>
            WhatsApp
          </a>
        </div>
      )}

      <style>{`
        @media (max-width: 768px) {
          .hidden-mobile { display: none !important; }
          .show-mobile   { display: block !important; }
        }
      `}</style>
    </header>
  )
}
