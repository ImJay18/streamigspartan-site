'use client'

import { Combo } from '@/types'
import { getWhatsAppLink } from '@/lib/utils'
import { WHATSAPP_NUMBER } from '@/lib/constants'

const grad = 'linear-gradient(135deg, #8B5CF6 0%, #D946EF 100%)'

const BADGE_BG: Record<string, string> = {
  purple:  '#8B5CF6',
  magenta: '#D946EF',
  green:   '#10b981',
}

function ComboCard({ combo }: { combo: Combo }) {
  const discount = combo.original_price > combo.price
    ? Math.round(((combo.original_price - combo.price) / combo.original_price) * 100) : 0

  return (
    <div style={{ position: 'relative', display: 'flex', flexDirection: 'column', background: '#0F0F0F', borderRadius: 20, padding: '28px 24px 24px', border: combo.is_featured ? '2px solid #8B5CF6' : '1px solid #1A1A2E', boxShadow: combo.is_featured ? '0 0 40px rgba(139,92,246,0.18)' : 'none', transition: 'transform 0.25s' }}
      onMouseEnter={e => (e.currentTarget.style.transform = 'translateY(-4px)')}
      onMouseLeave={e => (e.currentTarget.style.transform = 'translateY(0)')}>

      {combo.badge_text && (
        <div style={{ position: 'absolute', top: -13, left: 20 }}>
          <span style={{ fontSize: 11, fontWeight: 700, padding: '4px 12px', borderRadius: 999, color: '#fff', background: BADGE_BG[combo.badge_color] ?? '#8B5CF6' }}>
            {combo.badge_text}
          </span>
        </div>
      )}

      {/* Platform names */}
      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 6, marginBottom: 16, marginTop: 4 }}>
        {combo.platform_names.map((name, i) => (
          <span key={name} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ fontSize: 13, fontWeight: 700, color: '#fff' }}>{name}</span>
            {i < combo.platform_names.length - 1 && (
              <span style={{ color: '#8B5CF6', fontSize: 16, fontWeight: 300 }}>+</span>
            )}
          </span>
        ))}
      </div>

      <h3 style={{ fontSize: 18, fontWeight: 700, color: '#fff', marginBottom: 6 }}>{combo.name}</h3>
      <p style={{ fontSize: 13, color: '#A1A1AA', marginBottom: 'auto', paddingBottom: 20 }}>{combo.description}</p>

      {/* Price */}
      <div style={{ marginTop: 8 }}>
        {combo.original_price > 0 && combo.original_price > combo.price && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <span style={{ fontSize: 13, color: '#52525b', textDecoration: 'line-through' }}>{new Intl.NumberFormat('es-CO',{style:'currency',currency:'COP',minimumFractionDigits:0}).format(combo.original_price)}</span>
            {discount > 0 && <span style={{ fontSize: 12, fontWeight: 600, color: '#34d399' }}>-{discount}%</span>}
          </div>
        )}
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginBottom: 20 }}>
          <span style={{ fontSize: 34, fontWeight: 900, color: '#fff', lineHeight: 1 }}>{new Intl.NumberFormat('es-CO',{style:'currency',currency:'COP',minimumFractionDigits:0}).format(combo.price)}</span>
          <span style={{ fontSize: 13, color: '#A1A1AA' }}>/ mes</span>
        </div>
        <a href={getWhatsAppLink(WHATSAPP_NUMBER, `¡Hola! Quiero adquirir el ${combo.name} de Streaming Spartan.`)}
          target="_blank" rel="noopener noreferrer"
          style={{ display: 'block', textAlign: 'center', padding: '12px', borderRadius: 12, fontWeight: 600, fontSize: 14, color: '#fff', background: grad, textDecoration: 'none', transition: 'opacity 0.2s' }}
          onMouseEnter={e => (e.currentTarget.style.opacity = '0.9')}
          onMouseLeave={e => (e.currentTarget.style.opacity = '1')}>
          Elegir combo
        </a>
      </div>
    </div>
  )
}

export default function CombosSection({ combos }: { combos: Combo[] }) {
  return (
    <section id="combos" style={{ padding: '80px 0', background: '#080808' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 24px' }}>
        <div style={{ textAlign: 'center', marginBottom: 48 }}>
          <h2 style={{ fontSize: 'clamp(26px,4vw,38px)', fontWeight: 700, color: '#fff', marginBottom: 12 }}>
            Combos{' '}
            <span style={{ background: grad, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>populares</span>
          </h2>
          <p style={{ fontSize: 15, color: '#A1A1AA', maxWidth: 460, margin: '0 auto' }}>
            Ahorra más combinando tus plataformas favoritas en un solo plan.
          </p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 24, maxWidth: 960, margin: '0 auto' }} className="combos-grid">
          {combos.map(c => <ComboCard key={c.id} combo={c}/>)}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 28 }}>
          <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
            <path d="M7.5 1.5L1.5 4.5v5c0 3 2.4 5.8 6 6.7 3.6-.9 6-3.7 6-6.7v-5L7.5 1.5z" stroke="#8B5CF6" strokeWidth="1.3" strokeLinejoin="round"/>
            <path d="M4.5 7.5l2.5 2.5 4-4" stroke="#8B5CF6" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <span style={{ fontSize: 12, color: '#A1A1AA' }}>Todos nuestros combos incluyen garantía y soporte personalizado</span>
        </div>
      </div>
      <style>{`@media(max-width:768px){.combos-grid{grid-template-columns:1fr !important}}`}</style>
    </section>
  )
}
