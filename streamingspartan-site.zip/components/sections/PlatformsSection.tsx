'use client'

import Image from 'next/image'
import { Platform } from '@/types'
import AddToCartButton from './AddToCartButton'

const grad = 'linear-gradient(135deg, #8B5CF6 0%, #D946EF 100%)'
const COP  = (v: number) => new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', minimumFractionDigits: 0 }).format(v)

function PlatformCard({ p }: { p: Platform }) {
  const isPromo  = p.original_price > 0 && p.original_price > p.price
  const discount = isPromo ? Math.round(((p.original_price - p.price) / p.original_price) * 100) : 0

  return (
    <div style={{ position: 'relative', background: '#0F0F0F', border: isPromo ? '1px solid rgba(217,70,239,0.5)' : '1px solid #1A1A2E', borderRadius: 16, padding: 18, display: 'flex', flexDirection: 'column', gap: 12, transition: 'transform 0.25s, border-color 0.25s', boxShadow: isPromo ? '0 0 20px rgba(217,70,239,0.1)' : 'none' }}
      onMouseEnter={e => { e.currentTarget.style.borderColor = isPromo ? 'rgba(217,70,239,0.8)' : 'rgba(139,92,246,0.4)'; e.currentTarget.style.transform = 'translateY(-4px)' }}
      onMouseLeave={e => { e.currentTarget.style.borderColor = isPromo ? 'rgba(217,70,239,0.5)' : '#1A1A2E'; e.currentTarget.style.transform = 'translateY(0)' }}>

      {/* Badge Promo */}
      {isPromo && (
        <div style={{ position: 'absolute', top: -11, right: 14, zIndex: 2 }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 4, padding: '4px 10px', borderRadius: 999, background: 'linear-gradient(135deg,#D946EF,#8B5CF6)', boxShadow: '0 0 12px rgba(217,70,239,0.5)', fontSize: 10, fontWeight: 800, color: '#fff', letterSpacing: '0.06em' }}>
            <svg width="9" height="9" viewBox="0 0 10 10" fill="none"><path d="M5 1l1.1 2.4 2.6.2-1.9 1.7.6 2.6L5 6.7 2.6 7.9l.6-2.6L1.3 3.6l2.6-.2L5 1z" fill="white"/></svg>
            -{discount}% Promo
          </div>
        </div>
      )}

      {/* Logo */}
      <div style={{ height: 50, display: 'flex', alignItems: 'center', justifyContent: 'center', marginTop: isPromo ? 4 : 0 }}>
        <Image src={p.logo_url} alt={p.name} width={110} height={44} style={{ objectFit: 'contain', maxHeight: 44, width: 'auto' }} unoptimized/>
      </div>

      {/* Nombre + badge plan */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span style={{ fontSize: 13, fontWeight: 600, color: '#fff' }}>{p.name}</span>
        <span style={{ fontSize: 10, fontWeight: 700, padding: '3px 8px', borderRadius: 999, color: '#fff', background: grad }}>{p.plan_type}</span>
      </div>

      {/* Features */}
      <ul style={{ listStyle: 'none', margin: 0, padding: 0, display: 'flex', flexDirection: 'column', gap: 5, flex: 1 }}>
        {p.features.map(f => (
          <li key={f} style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 11, color: '#A1A1AA' }}>
            <svg width="11" height="11" viewBox="0 0 12 12" fill="none" style={{ flexShrink: 0 }}><circle cx="6" cy="6" r="5" stroke="#8B5CF6" strokeWidth="1.2"/><path d="M3.5 6l2 2 3-3" stroke="#8B5CF6" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/></svg>
            {f}
          </li>
        ))}
      </ul>

      {/* Precio */}
      <div style={{ paddingTop: 10, borderTop: '1px solid #1A1A2E' }}>
        {isPromo && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 2 }}>
            <span style={{ fontSize: 11, color: '#71717a', textDecoration: 'line-through' }}>{COP(p.original_price)}</span>
            <span style={{ fontSize: 10, fontWeight: 700, color: '#D946EF' }}>-{discount}%</span>
          </div>
        )}
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginBottom: 10 }}>
          <span style={{ fontSize: 12, color: '#A1A1AA' }}>Desde</span>
          <span style={{ color: isPromo ? '#D946EF' : '#fff', fontWeight: 700, fontSize: 16 }}>{COP(p.price)}</span>
          <span style={{ fontSize: 10, color: '#71717a' }}>/ pantalla</span>
        </div>
        <AddToCartButton platform={p}/>
      </div>
    </div>
  )
}

export default function PlatformsSection({ platforms }: { platforms: Platform[] }) {
  return (
    <section id="plataformas" style={{ padding: '80px 0' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 24px' }}>
        <div style={{ textAlign: 'center', marginBottom: 48 }}>
          <h2 style={{ fontSize: 'clamp(26px,4vw,38px)', fontWeight: 700, color: '#fff', marginBottom: 12 }}>
            Las mejores{' '}
            <span style={{ background: grad, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>plataformas</span>
            {' '}disponibles
          </h2>
          <p style={{ fontSize: 15, color: '#A1A1AA', maxWidth: 480, margin: '0 auto' }}>
            Selecciona tus plataformas y el número de pantallas. Detectamos combos automáticamente.
          </p>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 20 }} className="platforms-grid">
          {platforms.map(p => <PlatformCard key={p.id} p={p}/>)}
        </div>
      </div>
      <style>{`
        @media(max-width:1024px){.platforms-grid{grid-template-columns:repeat(3,1fr) !important}}
        @media(max-width:640px) {.platforms-grid{grid-template-columns:repeat(2,1fr) !important}}
      `}</style>
    </section>
  )
}
